#!/usr/bin/env python3
"""
CyberGuardian - Insider Threat Detection System
Standalone Demo (without Django)
"""

import json
import sqlite3
import os
from datetime import datetime
import joblib
import numpy as np
from sklearn.ensemble import RandomForestClassifier

# Database file
DB_FILE = "/home/claude/cyberguardian_project/db.sqlite3"
MODEL_FILE = "/home/claude/cyberguardian_project/insider_model.pkl"

# ==========================================
# DATABASE SETUP
# ==========================================
def init_database():
    """Initialize SQLite database with tables"""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    # Users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT,
            role TEXT DEFAULT 'user',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Security scans table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS security_scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            failed_logins INTEGER,
            login_attempts INTEGER,
            odd_hour BOOLEAN,
            new_device BOOLEAN,
            risk_score REAL,
            threat_detected BOOLEAN,
            scan_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    
    # Insert sample users if not exists
    cursor.execute("SELECT COUNT(*) FROM users")
    if cursor.fetchone()[0] == 0:
        sample_users = [
            ('john_doe', 'john@company.com', 'user'),
            ('jane_admin', 'jane@company.com', 'admin'),
            ('bob_analyst', 'bob@company.com', 'analyst'),
            ('alice_user', 'alice@company.com', 'user'),
        ]
        cursor.executemany(
            'INSERT INTO users (username, email, role) VALUES (?, ?, ?)',
            sample_users
        )
    
    conn.commit()
    conn.close()
    print(f"✅ Database initialized: {DB_FILE}")


# ==========================================
# ML MODEL TRAINING
# ==========================================
def train_ml_model():
    """Train the Random Forest model for threat detection"""
    print("\n🤖 Training ML Model...")
    
    # Training data
    # Features: [failed_logins, login_attempts, odd_hour, new_device]
    X = np.array([
        [0, 2, 0, 0],   # Normal
        [1, 5, 0, 0],   # Normal
        [2, 6, 1, 0],   # Normal
        [4, 10, 1, 1],  # Threat
        [6, 15, 1, 1],  # Threat
        [3, 8, 0, 1],   # Normal
        [7, 18, 1, 1],  # Threat
        [0, 1, 0, 0],   # Normal
        [5, 12, 1, 1],  # Threat
        [8, 20, 1, 1],  # Threat
    ])
    
    # Labels: 1 = Threat, 0 = Normal
    y = np.array([0, 0, 0, 1, 1, 0, 1, 0, 1, 1])
    
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=5,
        random_state=42
    )
    
    model.fit(X, y)
    joblib.dump(model, MODEL_FILE)
    
    # Display model accuracy
    accuracy = model.score(X, y) * 100
    print(f"   Model trained with {accuracy:.1f}% accuracy on training data")
    print(f"   Model saved to: {MODEL_FILE}")
    
    return model


# ==========================================
# RISK CALCULATION
# ==========================================
def calculate_risk(event_data):
    """Calculate risk using ML model"""
    # Load or train model
    if os.path.exists(MODEL_FILE):
        model = joblib.load(MODEL_FILE)
    else:
        model = train_ml_model()
    
    # Prepare features
    features = np.array([[
        event_data['failed_logins'],
        event_data['login_attempts'],
        int(event_data['odd_hour']),
        int(event_data['new_device'])
    ]])
    
    # Predict
    threat_probability = model.predict_proba(features)[0][1]
    threat_detected = threat_probability >= 0.6
    
    return {
        "risk_score": round(threat_probability * 100, 2),
        "threat_detected": threat_detected,
        "confidence": f"{round(threat_probability * 100, 2)}%",
        "model": "RandomForestClassifier"
    }


# ==========================================
# SECURITY SCAN FUNCTION
# ==========================================
def run_security_scan(user_id, event_data):
    """Run security scan and save to database"""
    # Calculate risk
    result = calculate_risk(event_data)
    
    # Save to database
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO security_scans 
        (user_id, failed_logins, login_attempts, odd_hour, new_device, 
         risk_score, threat_detected)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (
        user_id,
        event_data['failed_logins'],
        event_data['login_attempts'],
        event_data['odd_hour'],
        event_data['new_device'],
        result['risk_score'],
        result['threat_detected']
    ))
    
    scan_id = cursor.lastrowid
    conn.commit()
    conn.close()
    
    result['scan_id'] = scan_id
    return result


# ==========================================
# DEMO SCENARIOS
# ==========================================
def run_demo_scenarios():
    """Run various threat detection scenarios"""
    print("\n" + "="*60)
    print("🔍 RUNNING DEMO SECURITY SCANS")
    print("="*60)
    
    scenarios = [
        {
            'name': 'Normal User Activity',
            'user_id': 1,
            'data': {
                'failed_logins': 0,
                'login_attempts': 2,
                'odd_hour': False,
                'new_device': False
            }
        },
        {
            'name': 'Suspicious Activity - Multiple Failed Logins',
            'user_id': 2,
            'data': {
                'failed_logins': 5,
                'login_attempts': 8,
                'odd_hour': True,
                'new_device': False
            }
        },
        {
            'name': 'High Threat - New Device + Odd Hours',
            'user_id': 3,
            'data': {
                'failed_logins': 7,
                'login_attempts': 15,
                'odd_hour': True,
                'new_device': True
            }
        },
        {
            'name': 'Moderate Risk - New Device Only',
            'user_id': 4,
            'data': {
                'failed_logins': 2,
                'login_attempts': 5,
                'odd_hour': False,
                'new_device': True
            }
        }
    ]
    
    for i, scenario in enumerate(scenarios, 1):
        print(f"\n📊 Scenario {i}: {scenario['name']}")
        print("-" * 60)
        print(f"   Failed Logins: {scenario['data']['failed_logins']}")
        print(f"   Login Attempts: {scenario['data']['login_attempts']}")
        print(f"   Odd Hour Access: {scenario['data']['odd_hour']}")
        print(f"   New Device: {scenario['data']['new_device']}")
        
        result = run_security_scan(scenario['user_id'], scenario['data'])
        
        print(f"\n   🎯 ANALYSIS RESULTS:")
        print(f"   Risk Score: {result['risk_score']}%")
        print(f"   Threat Detected: {'🚨 YES' if result['threat_detected'] else '✅ NO'}")
        print(f"   Confidence: {result['confidence']}")
        print(f"   Scan ID: {result['scan_id']}")


# ==========================================
# DATABASE QUERY FUNCTIONS
# ==========================================
def show_database_stats():
    """Display database statistics"""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    print("\n" + "="*60)
    print("📈 DATABASE STATISTICS")
    print("="*60)
    
    # Total users
    cursor.execute("SELECT COUNT(*) FROM users")
    total_users = cursor.fetchone()[0]
    print(f"\n👥 Total Users: {total_users}")
    
    # Total scans
    cursor.execute("SELECT COUNT(*) FROM security_scans")
    total_scans = cursor.fetchone()[0]
    print(f"🔍 Total Security Scans: {total_scans}")
    
    # Threats detected
    cursor.execute("SELECT COUNT(*) FROM security_scans WHERE threat_detected = 1")
    threats = cursor.fetchone()[0]
    print(f"🚨 Threats Detected: {threats}")
    
    # Average risk score
    cursor.execute("SELECT AVG(risk_score) FROM security_scans")
    avg_risk = cursor.fetchone()[0]
    if avg_risk:
        print(f"📊 Average Risk Score: {avg_risk:.2f}%")
    
    # Recent scans
    print("\n📋 Recent Security Scans:")
    print("-" * 60)
    cursor.execute('''
        SELECT s.id, u.username, s.risk_score, s.threat_detected, s.scan_timestamp
        FROM security_scans s
        JOIN users u ON s.user_id = u.id
        ORDER BY s.scan_timestamp DESC
        LIMIT 10
    ''')
    
    for row in cursor.fetchall():
        scan_id, username, risk_score, threat, timestamp = row
        threat_icon = "🚨" if threat else "✅"
        print(f"   {threat_icon} Scan #{scan_id} | User: {username:15} | Risk: {risk_score:6.2f}% | {timestamp}")
    
    conn.close()


# ==========================================
# MAIN EXECUTION
# ==========================================
def main():
    print("="*60)
    print("🛡️  CYBERGUARDIAN - INSIDER THREAT DETECTION SYSTEM")
    print("="*60)
    
    # Initialize database
    init_database()
    
    # Train ML model
    train_ml_model()
    
    # Run demo scenarios
    run_demo_scenarios()
    
    # Show statistics
    show_database_stats()
    
    print("\n" + "="*60)
    print("✅ DEMO COMPLETED SUCCESSFULLY!")
    print("="*60)
    print(f"\n📁 Database Location: {DB_FILE}")
    print(f"🤖 ML Model Location: {MODEL_FILE}")
    print("\n💡 You can query the database using SQLite commands")
    print("   Example: sqlite3 db.sqlite3 'SELECT * FROM security_scans;'")


if __name__ == "__main__":
    main()
