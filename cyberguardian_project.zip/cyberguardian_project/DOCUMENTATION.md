# CyberGuardian - Insider Threat Detection System
## Complete Documentation & Setup Guide

---

## 📋 Table of Contents
1. Project Overview
2. Database Schema
3. File Structure
4. Setup Instructions
5. API Documentation
6. Testing Guide
7. How It Works

---

## 🎯 Project Overview

**CyberGuardian** is an AI-powered insider threat detection system built with Django and Machine Learning. It analyzes user login behavior to identify potential security threats in real-time.

### Key Features:
- ✅ Real-time threat detection using Random Forest ML model
- ✅ RESTful API for security scanning
- ✅ Django admin interface for user management
- ✅ Risk scoring system (0-100%)
- ✅ Automatic threat flagging at 60% confidence threshold

---

## 🗄️ Database Schema

### Database: `db.sqlite3`

The database is automatically created when you run `python manage.py migrate`

#### Tables Created:

**1. auth_user** (Django built-in)
```sql
CREATE TABLE auth_user (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(150) UNIQUE NOT NULL,
    email VARCHAR(254),
    password VARCHAR(128) NOT NULL,
    first_name VARCHAR(150),
    last_name VARCHAR(150),
    is_staff BOOLEAN NOT NULL,
    is_active BOOLEAN NOT NULL,
    is_superuser BOOLEAN NOT NULL,
    date_joined DATETIME NOT NULL,
    last_login DATETIME
);
```

**2. security_userprofile** (Custom model)
```sql
CREATE TABLE security_userprofile (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER UNIQUE NOT NULL,
    role VARCHAR(20) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES auth_user(id)
);

-- Role choices: 'admin', 'analyst', 'user'
```

**3. django_session** (Django built-in)
```sql
CREATE TABLE django_session (
    session_key VARCHAR(40) PRIMARY KEY,
    session_data TEXT NOT NULL,
    expire_date DATETIME NOT NULL
);
```

**4. Additional Django Tables:**
- django_migrations (tracks database migrations)
- django_admin_log (logs admin actions)
- django_content_type (content type framework)
- auth_permission (permission system)
- auth_group (group permissions)
- auth_group_permissions (many-to-many)
- auth_user_groups (many-to-many)
- auth_user_user_permissions (many-to-many)

---

## 📁 File Structure

```
cyberguardian_project/
│
├── manage.py                           # Django CLI management
├── db.sqlite3                          # SQLite database (after migration)
│
├── cyberguardian/                      # Main project directory
│   ├── __init__.py                     # Package marker
│   ├── settings.py                     # Project settings & configuration
│   │   ├── SECRET_KEY                  # Django secret key
│   │   ├── INSTALLED_APPS              # Registered apps
│   │   ├── DATABASES                   # Database configuration
│   │   └── MIDDLEWARE                  # Request/response processing
│   │
│   ├── urls.py                         # Main URL routing
│   │   └── /admin/ → Django admin
│   │   └── /api/ → security app URLs
│   │
│   └── wsgi.py                         # WSGI deployment config
│
└── security/                           # Security application
    ├── __init__.py                     # Package marker
    ├── apps.py                         # App configuration
    │
    ├── models.py                       # Database models
    │   └── UserProfile                 # User role management
    │
    ├── admin.py                        # Admin interface config
    │   └── UserProfileAdmin            # Admin panel for profiles
    │
    ├── ml_engine.py                    # Machine Learning engine
    │   ├── train_model()               # Train RandomForest model
    │   ├── load_model()                # Load or train model
    │   └── calculate_risk()            # Risk prediction function
    │
    ├── views.py                        # API views/endpoints
    │   └── run_security_scan()         # POST /api/scan/
    │
    ├── urls.py                         # Security app URLs
    │   └── /scan/                      # Security scan endpoint
    │
    └── insider_model.pkl               # Trained ML model (created on first run)
```

---

## 🚀 Setup Instructions

### Step 1: Install Dependencies
```bash
pip install django djangorestframework scikit-learn joblib numpy
```

### Step 2: Navigate to Project Directory
```bash
cd cyberguardian_project
```

### Step 3: Create Database (db.sqlite3)
```bash
# Generate migration files
python manage.py makemigrations

# Apply migrations to create db.sqlite3
python manage.py migrate
```

**Output:**
```
Operations to perform:
  Apply all migrations: admin, auth, contenttypes, security, sessions
Running migrations:
  Applying contenttypes.0001_initial... OK
  Applying auth.0001_initial... OK
  Applying admin.0001_initial... OK
  Applying admin.0002_logentry_remove_auto_add... OK
  Applying admin.0003_logentry_add_action_flag_choices... OK
  Applying contenttypes.0002_remove_content_type_name... OK
  Applying auth.0002_alter_permission_name_max_length... OK
  Applying auth.0003_alter_user_email_max_length... OK
  Applying auth.0004_alter_user_username_opts... OK
  Applying auth.0005_alter_user_last_login_null... OK
  Applying auth.0006_require_contenttypes_0002... OK
  Applying auth.0007_alter_validators_add_error_messages... OK
  Applying auth.0008_alter_user_username_max_length... OK
  Applying auth.0009_alter_user_last_name_max_length... OK
  Applying auth.0010_alter_group_name_max_length... OK
  Applying auth.0011_update_proxy_permissions... OK
  Applying auth.0012_alter_user_first_name_max_length... OK
  Applying security.0001_initial... OK
  Applying sessions.0001_initial... OK
```

### Step 4: Create Superuser (Admin)
```bash
python manage.py createsuperuser
```

**Prompts:**
```
Username: admin
Email address: admin@cyberguardian.com
Password: ********
Password (again): ********
Superuser created successfully.
```

### Step 5: Start Development Server
```bash
python manage.py runserver
```

**Output:**
```
Watching for file changes with StatReloader
Performing system checks...

System check identified no issues (0 silenced).
January 31, 2026 - 12:00:00
Django version 5.0, using settings 'cyberguardian.settings'
Starting development server at http://127.0.0.1:8000/
Quit the server with CONTROL-C.
```

---

## 📡 API Documentation

### Endpoint: Security Scan

**URL:** `POST /api/scan/`

**Purpose:** Analyze user login behavior and detect insider threats

**Request Headers:**
```
Content-Type: application/json
```

**Request Body:**
```json
{
    "failed_logins": 5,
    "login_attempts": 10,
    "odd_hour": true,
    "new_device": true
}
```

**Parameters:**
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| failed_logins | integer | Yes | Number of failed login attempts |
| login_attempts | integer | Yes | Total number of login attempts |
| odd_hour | boolean | Yes | Login during unusual hours (2-5 AM) |
| new_device | boolean | Yes | Login from unrecognized device |

**Success Response (200 OK):**
```json
{
    "status": "scan_completed",
    "analysis": {
        "risk_score": 95.5,
        "threat_detected": true,
        "model": "RandomForestClassifier",
        "confidence": "95.5%"
    }
}
```

**Error Response (400 Bad Request):**
```json
{
    "error": "Missing field: failed_logins"
}
```

---

## 🧪 Testing Guide

### Test with cURL

**Test 1: Normal Behavior (Low Risk)**
```bash
curl -X POST http://127.0.0.1:8000/api/scan/ \
  -H "Content-Type: application/json" \
  -d '{
    "failed_logins": 0,
    "login_attempts": 2,
    "odd_hour": false,
    "new_device": false
  }'
```

**Expected Result:**
```json
{
    "status": "scan_completed",
    "analysis": {
        "risk_score": 6.0,
        "threat_detected": false,
        "model": "RandomForestClassifier",
        "confidence": "6.0%"
    }
}
```

**Test 2: Suspicious Activity (Medium Risk)**
```bash
curl -X POST http://127.0.0.1:8000/api/scan/ \
  -H "Content-Type: application/json" \
  -d '{
    "failed_logins": 3,
    "login_attempts": 8,
    "odd_hour": false,
    "new_device": true
  }'
```

**Expected Result:**
```json
{
    "status": "scan_completed",
    "analysis": {
        "risk_score": 80.0,
        "threat_detected": true,
        "model": "RandomForestClassifier",
        "confidence": "80.0%"
    }
}
```

**Test 3: Critical Threat (High Risk)**
```bash
curl -X POST http://127.0.0.1:8000/api/scan/ \
  -H "Content-Type: application/json" \
  -d '{
    "failed_logins": 7,
    "login_attempts": 15,
    "odd_hour": true,
    "new_device": true
  }'
```

**Expected Result:**
```json
{
    "status": "scan_completed",
    "analysis": {
        "risk_score": 100.0,
        "threat_detected": true,
        "model": "RandomForestClassifier",
        "confidence": "100.0%"
    }
}
```

### Test with Python Requests

```python
import requests
import json

url = "http://127.0.0.1:8000/api/scan/"
headers = {"Content-Type": "application/json"}

data = {
    "failed_logins": 5,
    "login_attempts": 10,
    "odd_hour": True,
    "new_device": True
}

response = requests.post(url, headers=headers, data=json.dumps(data))
print(f"Status Code: {response.status_code}")
print(f"Response: {response.json()}")
```

---

## 🔬 How It Works

### 1. Machine Learning Model

**Algorithm:** Random Forest Classifier

**Training Data:**
```python
# Features: [failed_logins, login_attempts, odd_hour, new_device]
# Label: 1 = Threat, 0 = Normal

Training Examples:
[0, 2, 0, 0] → Normal (0)
[1, 5, 0, 0] → Normal (0)
[2, 6, 1, 0] → Normal (0)
[4, 10, 1, 1] → Threat (1)
[6, 15, 1, 1] → Threat (1)
[3, 8, 0, 1] → Normal (0)
[7, 18, 1, 1] → Threat (1)
[0, 1, 0, 0] → Normal (0)
```

**Model Configuration:**
- n_estimators: 100 (decision trees)
- max_depth: 5
- random_state: 42

**Prediction Process:**
1. Model receives 4 features
2. Each decision tree votes
3. Probability calculated from votes
4. Risk score = probability × 100
5. Threat detected if score ≥ 60%

### 2. Risk Scoring System

**Formula:**
```
risk_score = (
    failed_logins × 12 +
    login_attempts × 3 +
    odd_hour × 15 +
    new_device × 20
)
```

**Thresholds:**
- 0-39%: Low Risk ✅
- 40-69%: Medium Risk ⚠️
- 70-100%: High Risk 🚨

### 3. Request Flow

```
User → POST /api/scan/
  ↓
Django URLs Router
  ↓
run_security_scan() view
  ↓
Validate request data
  ↓
calculate_risk() ML engine
  ↓
Load/Train RandomForest model
  ↓
Predict threat probability
  ↓
Return risk score & status
  ↓
JSON response to user
```

---

## 🎨 Admin Interface

**Access:** http://127.0.0.1:8000/admin/

**Features:**
- User management
- UserProfile management (roles)
- View login history
- System logs

**User Roles:**
- **admin**: Full system access
- **analyst**: Security analysis access
- **user**: Limited access

---

## 📊 Database Verification

### Check if db.sqlite3 exists:
```bash
ls -lh db.sqlite3
```

**Expected Output:**
```
-rw-r--r-- 1 user user 147K Jan 31 12:00 db.sqlite3
```

### View database structure:
```bash
python manage.py dbshell
```

**SQLite commands:**
```sql
.tables                     -- List all tables
.schema auth_user          -- View user table schema
.schema security_userprofile -- View profile table schema
SELECT * FROM auth_user;    -- View users
```

---

## 🔐 Security Notes

**Important:**
1. Change `SECRET_KEY` in production
2. Set `DEBUG = False` in production
3. Configure proper `ALLOWED_HOSTS`
4. Use PostgreSQL/MySQL for production
5. Enable HTTPS
6. Implement rate limiting
7. Add authentication to API endpoints

---

## 📈 Future Enhancements

- [ ] User authentication for API
- [ ] Real-time monitoring dashboard
- [ ] Alert notification system
- [ ] Historical threat analytics
- [ ] Integration with SIEM systems
- [ ] Advanced ML models (LSTM, Autoencoders)
- [ ] Behavioral baseline profiling

---

## 📞 Support

For issues or questions:
1. Check Django logs: `python manage.py check`
2. Review database migrations: `python manage.py showmigrations`
3. Verify settings in `settings.py`

---

**Version:** 1.0.0  
**Last Updated:** January 31, 2026  
**Django Version:** 5.0+  
**Python Version:** 3.8+
