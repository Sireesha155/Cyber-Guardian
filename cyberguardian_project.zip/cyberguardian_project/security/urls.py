from django.urls import path
from .views import run_security_scan

urlpatterns = [
    path('scan/', run_security_scan, name='run_security_scan'),
]
