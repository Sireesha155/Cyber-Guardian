#!/usr/bin/env python3
"""
CyberGuardian - Insider Threat Detection System
Demo Script (Simulated without Django server)
"""

import json
import numpy as np
from datetime import datetime

# Simulated ML Engine
class MLEngine:
    @staticmethod
    def calculate_risk(event):
        """
        Simulates ML-based risk calculation
        Features: failed_logins, login_attempts, odd_hour, new_device
        """
        # Simple rule-based simulation (in real app, uses trained RandomForest)
        failed_logins = event['failed_logins']
        login_attempts = event['login_attempts']
        odd_hour = int(event['odd_hour'])
        new_device = int(event['new_device'])
        
        # Calculate risk score
        risk_score = 0
        risk_score += failed_logins * 12
        risk_score += login_attempts * 3
        risk_score += odd_hour * 15
        risk_score += new_device * 20
        
        risk_score = min(risk_score, 100)
        threat_detected = risk_score >= 60
        
        return {
            "risk_score": round(risk_score, 2),
            "threat_detected": threat_detected,
            "model": "RandomForestClassifier",
            "confidence": f"{round(risk_score, 2)}%"
        }

# Simulated API Endpoint
def run_security_scan(data):
    """Simulates the /api/scan/ endpoint"""
    required_fields = ['failed_logins', 'login_attempts', 'odd_hour', 'new_device']
    
    # Validate
    for field in required_fields:
        if field not in data:
            return {"error": f"Missing field: {field}"}, 400
    
    # Run ML analysis
    result = MLEngine.calculate_risk(data)
    
    return {
        "status": "scan_completed",
        "timestamp": datetime.now().isoformat(),
        "analysis": result
    }, 200

# Test Cases
print("=" * 70)
print("CYBERGUARDIAN - INSIDER THREAT DETECTION SYSTEM")
print("=" * 70)
print()

test_cases = [
    {
        "name": "Normal User Behavior",
        "data": {
            "failed_logins": 0,
            "login_attempts": 2,
            "odd_hour": False,
            "new_device": False
        }
    },
    {
        "name": "Suspicious Activity - Multiple Failed Logins",
        "data": {
            "failed_logins": 5,
            "login_attempts": 8,
            "odd_hour": False,
            "new_device": False
        }
    },
    {
        "name": "High Risk - Odd Hours + New Device",
        "data": {
            "failed_logins": 3,
            "login_attempts": 10,
            "odd_hour": True,
            "new_device": True
        }
    },
    {
        "name": "Critical Threat - All Risk Factors",
        "data": {
            "failed_logins": 7,
            "login_attempts": 15,
            "odd_hour": True,
            "new_device": True
        }
    }
]

for idx, test in enumerate(test_cases, 1):
    print(f"TEST CASE {idx}: {test['name']}")
    print("-" * 70)
    print(f"Input Data:")
    print(f"  Failed Logins: {test['data']['failed_logins']}")
    print(f"  Login Attempts: {test['data']['login_attempts']}")
    print(f"  Odd Hour Login: {test['data']['odd_hour']}")
    print(f"  New Device: {test['data']['new_device']}")
    print()
    
    response, status_code = run_security_scan(test['data'])
    
    print(f"API Response (Status: {status_code}):")
    print(json.dumps(response, indent=2))
    
    if status_code == 200:
        analysis = response['analysis']
        print()
        print(f"🎯 THREAT ASSESSMENT:")
        print(f"   Risk Score: {analysis['risk_score']}%")
        print(f"   Threat Detected: {'⚠️  YES' if analysis['threat_detected'] else '✅ NO'}")
        print(f"   Model: {analysis['model']}")
    
    print()
    print("=" * 70)
    print()

print("\n📊 SUMMARY OF DATABASE STRUCTURE:")
print("-" * 70)
print("""
Database: db.sqlite3

Tables:
1. auth_user (Django built-in)
   - id, username, email, password, is_staff, is_active, etc.

2. security_userprofile
   - id, user_id (FK), role (admin/analyst/user)

3. django_session (Django built-in)
   - session tracking

4. Plus Django admin tables

ML Model: security/insider_model.pkl
   - Algorithm: RandomForestClassifier
   - Features: 4 (failed_logins, login_attempts, odd_hour, new_device)
   - Training samples: 8
   - Threshold: 60% confidence
""")

print("\n🌐 API ENDPOINTS:")
print("-" * 70)
print("""
POST /api/scan/
   Purpose: Run insider threat detection
   
   Request Body:
   {
     "failed_logins": <int>,
     "login_attempts": <int>,
     "odd_hour": <boolean>,
     "new_device": <boolean>
   }
   
   Response:
   {
     "status": "scan_completed",
     "timestamp": "2026-01-31T...",
     "analysis": {
       "risk_score": <float>,
       "threat_detected": <boolean>,
       "model": "RandomForestClassifier",
       "confidence": "<percentage>"
     }
   }

GET /admin/
   Purpose: Django admin interface
   Access: Superuser only
""")

print("\n⚙️  HOW TO RUN (When Django is installed):")
print("-" * 70)
print("""
1. Install dependencies:
   pip install django djangorestframework scikit-learn joblib numpy

2. Run migrations:
   python manage.py makemigrations
   python manage.py migrate

3. Create superuser:
   python manage.py createsuperuser

4. Start server:
   python manage.py runserver

5. Access:
   - Admin: http://127.0.0.1:8000/admin/
   - API: http://127.0.0.1:8000/api/scan/

6. Test API with curl:
   curl -X POST http://127.0.0.1:8000/api/scan/ \\
     -H "Content-Type: application/json" \\
     -d '{
       "failed_logins": 5,
       "login_attempts": 10,
       "odd_hour": true,
       "new_device": true
     }'
""")
