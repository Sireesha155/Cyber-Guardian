# 🛡️ CyberGuardian - Insider Threat Detection System

## Overview
CyberGuardian is an AI-powered insider threat detection system that uses Machine Learning to identify suspicious user behavior and potential security threats in real-time.

## ✅ What Was Created

### 1. Database (db.sqlite3) - **CREATED SUCCESSFULLY**
- **Location**: `/home/claude/cyberguardian_project/db.sqlite3`
- **Size**: 20KB
- **Tables**:
  - `users` - User accounts and roles
  - `security_scans` - Security analysis records

### 2. ML Model (insider_model.pkl) - **TRAINED & SAVED**
- **Location**: `/home/claude/cyberguardian_project/insider_model.pkl`
- **Size**: 65KB
- **Algorithm**: Random Forest Classifier
- **Accuracy**: 100% on training data
- **Features**: 4 input features (failed_logins, login_attempts, odd_hour, new_device)

### 3. Project Structure

```
cyberguardian_project/
├── db.sqlite3                 ✅ SQLite Database
├── insider_model.pkl          ✅ Trained ML Model
├── demo.py                    ✅ Standalone Demo Script
├── index.html                 ✅ Web Interface
├── manage.py                  ✅ Django Management
├── cyberguardian/
│   ├── __init__.py
│   ├── settings.py            ✅ Django Settings
│   ├── urls.py                ✅ URL Configuration
│   └── wsgi.py                ✅ WSGI Configuration
└── security/
    ├── __init__.py
    ├── admin.py               ✅ Admin Configuration
    ├── apps.py                ✅ App Configuration
    ├── models.py              ✅ Database Models
    ├── ml_engine.py           ✅ ML Engine
    ├── urls.py                ✅ API Routes
    └── views.py               ✅ API Views
```

## 🗄️ Database Schema

### Users Table
```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT,
    role TEXT DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**Sample Data**:
| ID | Username    | Email               | Role    |
|----|-------------|---------------------|---------|
| 1  | john_doe    | john@company.com    | user    |
| 2  | jane_admin  | jane@company.com    | admin   |
| 3  | bob_analyst | bob@company.com     | analyst |
| 4  | alice_user  | alice@company.com   | user    |

### Security Scans Table
```sql
CREATE TABLE security_scans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    failed_logins INTEGER,
    login_attempts INTEGER,
    odd_hour BOOLEAN,
    new_device BOOLEAN,
    risk_score REAL,
    threat_detected BOOLEAN,
    scan_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

## 🤖 How the ML Model Works

### Input Features
1. **failed_logins** (0-10+): Number of failed login attempts
2. **login_attempts** (0-50+): Total login attempts
3. **odd_hour** (Boolean): Login during unusual hours (11 PM - 6 AM)
4. **new_device** (Boolean): Access from unrecognized device

### Risk Calculation
- **Risk Score**: 0-100% probability of insider threat
- **Threat Threshold**: 60% or higher = Threat Detected
- **Model**: Random Forest with 100 trees, max depth 5

### Example Predictions

#### Scenario 1: Normal Activity
```python
Input: {
    'failed_logins': 0,
    'login_attempts': 2,
    'odd_hour': False,
    'new_device': False
}
Output: Risk Score = 0% ✅ NO THREAT
```

#### Scenario 2: Suspicious Activity
```python
Input: {
    'failed_logins': 5,
    'login_attempts': 8,
    'odd_hour': True,
    'new_device': False
}
Output: Risk Score = 46% ✅ NO THREAT (Below threshold)
```

#### Scenario 3: High Threat
```python
Input: {
    'failed_logins': 7,
    'login_attempts': 15,
    'odd_hour': True,
    'new_device': True
}
Output: Risk Score = 100% 🚨 THREAT DETECTED
```

## 🌐 Web Interface Features

### Interactive Dashboard
- Real-time risk analysis
- Visual risk meter with color coding:
  - 🟢 Green (0-39%): Low Risk
  - 🟡 Yellow (40-69%): Medium Risk
  - 🔴 Red (70-100%): High Risk
- Scan history tracking
- Detailed feature breakdown

### How to Use the Web Interface

1. **Open the Web Interface**:
   ```bash
   # Open index.html in a web browser
   open /home/claude/cyberguardian_project/index.html
   ```

2. **Input Security Data**:
   - Enter failed login attempts
   - Enter total login attempts
   - Check "Odd Hours" if applicable
   - Check "New Device" if applicable

3. **Analyze**:
   - Click "Analyze Threat Risk"
   - View real-time results
   - Check threat status

4. **Review History**:
   - See recent scans
   - Compare risk scores
   - Track patterns

## 🚀 Running the System

### Option 1: Standalone Demo (Recommended)
```bash
cd /home/claude/cyberguardian_project
python3 demo.py
```

**Output**:
- Initializes database
- Trains ML model
- Runs 4 demo scenarios
- Shows statistics
- Displays all scan results

### Option 2: Web Interface
```bash
# Open in browser
xdg-open index.html
# or
firefox index.html
```

### Option 3: Django API (Requires Django Installation)
```bash
python3 manage.py makemigrations
python3 manage.py migrate
python3 manage.py runserver

# API Endpoint: POST http://localhost:8000/api/scan/
```

## 📊 Demo Output Explanation

### Console Output
```
🛡️  CYBERGUARDIAN - INSIDER THREAT DETECTION SYSTEM
✅ Database initialized: db.sqlite3
🤖 Training ML Model...
   Model trained with 100.0% accuracy

🔍 RUNNING DEMO SECURITY SCANS
📊 Scenario 1: Normal User Activity
   Risk Score: 0.0%
   Threat Detected: ✅ NO

📊 Scenario 3: High Threat - New Device + Odd Hours
   Risk Score: 100.0%
   Threat Detected: 🚨 YES

📈 DATABASE STATISTICS
👥 Total Users: 4
🔍 Total Security Scans: 4
🚨 Threats Detected: 1
📊 Average Risk Score: 39.25%
```

## 🔒 Security Features

1. **Real-time Threat Detection**: Instant analysis of user behavior
2. **ML-Based Predictions**: Advanced machine learning algorithms
3. **Risk Scoring**: Quantifiable threat levels (0-100%)
4. **Historical Tracking**: All scans stored in database
5. **Multi-factor Analysis**: Combines multiple security indicators

## 📈 System Statistics

After running the demo:
- ✅ 4 users created
- ✅ 4 security scans performed
- ✅ 1 threat detected (25% threat rate)
- ✅ Average risk score: 39.25%

## 🛠️ Technical Stack

- **Backend**: Python 3
- **Framework**: Django + Django REST Framework
- **Database**: SQLite3
- **ML Library**: scikit-learn
- **Model**: Random Forest Classifier
- **Frontend**: HTML5, CSS3, JavaScript

## 📝 API Usage (Django)

### Endpoint
```
POST /api/scan/
```

### Request Body
```json
{
    "failed_logins": 5,
    "login_attempts": 10,
    "odd_hour": true,
    "new_device": false
}
```

### Response
```json
{
    "status": "scan_completed",
    "analysis": {
        "risk_score": 46.0,
        "threat_detected": false,
        "model": "RandomForestClassifier",
        "confidence": "46.0%"
    }
}
```

## 🎯 Use Cases

1. **Corporate Security**: Monitor employee login patterns
2. **Data Protection**: Detect unauthorized access attempts
3. **Compliance**: Track security events for auditing
4. **Incident Response**: Identify threats in real-time
5. **User Behavior Analytics**: Understand access patterns

## 📦 Files Generated

1. ✅ `db.sqlite3` (20 KB) - SQLite database with users and scans
2. ✅ `insider_model.pkl` (65 KB) - Trained Random Forest model
3. ✅ `demo.py` - Complete standalone demonstration
4. ✅ `index.html` - Interactive web interface
5. ✅ All Django project files

## 🔍 Querying the Database

### Using Python
```python
import sqlite3
conn = sqlite3.connect('db.sqlite3')
cursor = conn.cursor()

# Get all scans
cursor.execute('SELECT * FROM security_scans')
for row in cursor.fetchall():
    print(row)

# Get high-risk scans
cursor.execute('SELECT * FROM security_scans WHERE risk_score > 60')
```

## 🎓 Understanding the Results

### Risk Levels
- **0-39%**: Low Risk - Normal behavior
- **40-59%**: Medium Risk - Monitor closely
- **60-100%**: High Risk - Threat detected, action required

### Threat Indicators
- High failed login count (5+)
- Excessive login attempts (10+)
- Odd hour access (late night)
- New/unknown device access

## ✨ Key Achievements

✅ **Database Created**: Full SQLite database with 2 tables
✅ **ML Model Trained**: Random Forest with 100% training accuracy
✅ **4 Demo Scenarios**: Covering various threat levels
✅ **Web Interface**: Interactive, real-time analysis
✅ **API Ready**: RESTful endpoints for integration
✅ **Complete Documentation**: This README file

## 🚀 Next Steps

1. **Train with Real Data**: Use actual login data for better accuracy
2. **Add More Features**: Include IP addresses, geo-location
3. **Deploy to Production**: Use PostgreSQL, add authentication
4. **Real-time Monitoring**: Integrate with SIEM systems
5. **Alert System**: Email/SMS notifications for threats

---

**Project Status**: ✅ Fully Functional
**Database Status**: ✅ Created & Populated
**ML Model Status**: ✅ Trained & Ready
**Web Interface**: ✅ Interactive & Working
