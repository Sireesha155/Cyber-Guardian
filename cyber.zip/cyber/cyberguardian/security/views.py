from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .ml_engine import calculate_risk


@api_view(['POST'])
def run_security_scan(request):
    """
    Insider Threat Detection API
    """

    data = request.data

    # Basic validation
    required_fields = [
        'failed_logins',
        'login_attempts',
        'odd_hour',
        'new_device'
    ]

    for field in required_fields:
        if field not in data:
            return Response(
                {"error": f"Missing field: {field}"},
                status=status.HTTP_400_BAD_REQUEST
            )

    # Run ML risk analysis
    result = calculate_risk(data)

    return Response(
        {
            "status": "scan_completed",
            "analysis": result
        },
        status=status.HTTP_200_OK
    )

