import os
import joblib
import numpy as np
from sklearn.ensemble import RandomForestClassifier

MODEL_PATH = "security/insider_model.pkl"

# -----------------------------
# 1. TRAIN ML MODEL (One-time)
# -----------------------------
def train_model():
    """
    Features:
    [failed_logins, login_attempts, odd_hour, new_device]
    Label:
    1 = Threat, 0 = Normal
    """

    X = np.array([
        [0, 2, 0, 0],
        [1, 5, 0, 0],
        [2, 6, 1, 0],
        [4, 10, 1, 1],
        [6, 15, 1, 1],
        [3, 8, 0, 1],
        [7, 18, 1, 1],
        [0, 1, 0, 0]
    ])

    y = np.array([0, 0, 0, 1, 1, 0, 1, 0])

    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=5,
        random_state=42
    )

    model.fit(X, y)
    joblib.dump(model, MODEL_PATH)
    return model


# -----------------------------
# 2. LOAD OR TRAIN MODEL
# -----------------------------
def load_model():
    if os.path.exists(MODEL_PATH):
        return joblib.load(MODEL_PATH)
    return train_model()


# -----------------------------
# 3. ML-BASED RISK PREDICTION
# -----------------------------
def calculate_risk(event):
    """
    event = {
        'failed_logins': int,
        'login_attempts': int,
        'odd_hour': bool,
        'new_device': bool
    }
    """

    model = load_model()

    features = np.array([[
        event['failed_logins'],
        event['login_attempts'],
        int(event['odd_hour']),
        int(event['new_device'])
    ]])

    threat_probability = model.predict_proba(features)[0][1]
    threat_detected = threat_probability >= 0.6

    return {
        "risk_score": round(threat_probability * 100, 2),
        "threat_detected": threat_detected,
        "model": "RandomForestClassifier",
        "confidence": f"{round(threat_probability * 100, 2)}%"
    }
