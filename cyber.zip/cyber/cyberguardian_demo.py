#!/usr/bin/env python3
"""
CyberGuardian - Insider Threat Detection System Demo
This script simulates the Django application functionality
"""

import json
import numpy as np
from datetime import datetime

print("=" * 70)
print("🔒 CYBERGUARDIAN - INSIDER THREAT DETECTION SYSTEM")
print("=" * 70)
print()

# Simulate the ML model
class MockMLEngine:
    """Simulates the Random Forest Classifier for threat detection"""
    
    @staticmethod
    def calculate_risk(event):
        """
        Calculate risk based on user behavior patterns
        Features: [failed_logins, login_attempts, odd_hour, new_device]
        """
        failed_logins = event['failed_logins']
        login_attempts = event['login_attempts']
        odd_hour = int(event['odd_hour'])
        new_device = int(event['new_device'])
        
        # Simple risk calculation algorithm
        base_risk = 0.0
        
        # Weight factors
        base_risk += failed_logins * 0.15
        base_risk += (login_attempts - 2) * 0.05 if login_attempts > 2 else 0
        base_risk += odd_hour * 0.25
        base_risk += new_device * 0.20
        
        # Normalize to 0-1 range
        risk_probability = min(base_risk, 1.0)
        
        # Determine threat level
        threat_detected = risk_probability >= 0.6
        
        return {
            "risk_score": round(risk_probability * 100, 2),
            "threat_detected": threat_detected,
            "model": "RandomForestClassifier",
            "confidence": f"{round(risk_probability * 100, 2)}%"
        }


# Test scenarios
test_scenarios = [
    {
        "name": "Normal User Activity",
        "description": "Regular login during business hours from known device",
        "data": {
            "failed_logins": 0,
            "login_attempts": 2,
            "odd_hour": False,
            "new_device": False
        }
    },
    {
        "name": "Suspicious Activity - Multiple Failed Logins",
        "description": "Several failed login attempts during business hours",
        "data": {
            "failed_logins": 3,
            "login_attempts": 8,
            "odd_hour": False,
            "new_device": False
        }
    },
    {
        "name": "High Risk - Odd Hour + New Device",
        "description": "Login from new device at 3 AM with failed attempts",
        "data": {
            "failed_logins": 4,
            "login_attempts": 10,
            "odd_hour": True,
            "new_device": True
        }
    },
    {
        "name": "Critical Threat - Insider Attack Pattern",
        "description": "Multiple failed logins, odd hours, new device",
        "data": {
            "failed_logins": 7,
            "login_attempts": 18,
            "odd_hour": True,
            "new_device": True
        }
    },
    {
        "name": "Medium Risk - New Device Only",
        "description": "First-time login from new device during work hours",
        "data": {
            "failed_logins": 1,
            "login_attempts": 5,
            "odd_hour": False,
            "new_device": True
        }
    }
]

# Initialize ML Engine
ml_engine = MockMLEngine()

print("🔍 RUNNING SECURITY SCANS...\n")

# Process each scenario
for i, scenario in enumerate(test_scenarios, 1):
    print(f"\n{'─' * 70}")
    print(f"TEST CASE #{i}: {scenario['name']}")
    print(f"{'─' * 70}")
    print(f"Description: {scenario['description']}")
    print(f"\n📊 Input Data:")
    for key, value in scenario['data'].items():
        print(f"   • {key.replace('_', ' ').title()}: {value}")
    
    # Run security scan
    result = ml_engine.calculate_risk(scenario['data'])
    
    print(f"\n🎯 Analysis Results:")
    print(f"   • Risk Score: {result['risk_score']}%")
    print(f"   • Threat Detected: {'⚠️  YES - ALERT!' if result['threat_detected'] else '✅ NO - Safe'}")
    print(f"   • Model: {result['model']}")
    print(f"   • Confidence: {result['confidence']}")
    
    # Risk level classification
    risk_score = result['risk_score']
    if risk_score < 30:
        risk_level = "🟢 LOW RISK"
    elif risk_score < 60:
        risk_level = "🟡 MEDIUM RISK"
    elif risk_score < 80:
        risk_level = "🟠 HIGH RISK"
    else:
        risk_level = "🔴 CRITICAL RISK"
    
    print(f"   • Risk Level: {risk_level}")
    
    # Recommendations
    print(f"\n💡 Recommended Actions:")
    if result['threat_detected']:
        print("   1. Immediately notify security team")
        print("   2. Require additional authentication")
        print("   3. Monitor user activity closely")
        print("   4. Consider temporary access restriction")
    else:
        print("   1. Continue normal monitoring")
        print("   2. Log activity for future analysis")

print(f"\n\n{'=' * 70}")
print("📈 SUMMARY STATISTICS")
print(f"{'=' * 70}")
print(f"Total Scans: {len(test_scenarios)}")
print(f"Threats Detected: {sum(1 for s in test_scenarios if ml_engine.calculate_risk(s['data'])['threat_detected'])}")
print(f"Safe Activities: {sum(1 for s in test_scenarios if not ml_engine.calculate_risk(s['data'])['threat_detected'])}")

print(f"\n{'=' * 70}")
print("🌐 API ENDPOINT INFORMATION")
print(f"{'=' * 70}")
print("Endpoint: POST /api/scan/")
print("Content-Type: application/json")
print("\nExample Request Body:")
print(json.dumps({
    "failed_logins": 4,
    "login_attempts": 10,
    "odd_hour": True,
    "new_device": True
}, indent=2))

print("\nExample Response:")
print(json.dumps({
    "status": "scan_completed",
    "analysis": {
        "risk_score": 85.0,
        "threat_detected": True,
        "model": "RandomForestClassifier",
        "confidence": "85.0%"
    }
}, indent=2))

print(f"\n{'=' * 70}")
print("✅ DEMO COMPLETED SUCCESSFULLY")
print(f"{'=' * 70}\n")
